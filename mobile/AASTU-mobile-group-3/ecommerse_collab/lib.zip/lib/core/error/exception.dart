class ServerException implements Exception {

  
  ServerException();
  @override
  String toString() {
    return 'Server Exception';
  }
}
