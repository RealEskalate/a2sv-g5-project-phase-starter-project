import 'package:bloc/bloc.dart';

import '../../domain/entity/user.dart';
import '../../domain/usecases/login.dart';
import '../../domain/usecases/sign_up.dart';
import 'events.dart';
import 'states.dart';

class UserBloc extends Bloc<UserEvent, UserState>{
  final SignUpUseCase signUpUseCase;
  final LoginUseCase loginUseCase;
  UserBloc({
    required this.signUpUseCase,
    required this.loginUseCase
  }):super(UserInitialState()){
    on<RegisterUserEvent>((event, emit) async {
      emit (RegisterLoadingState());
      try{
        final user = await signUpUseCase.call(email: event.email, password: event.password, username: event.username);
        // final user =  User(id: '1', email: event.email, password: event.password, username: event.username);
        print("from user bloc $user");
        emit(UserRegisteredState(user));
      } catch (e) {
        emit(RegisterErrorState("Fail to Register"));
      }
    },);
    on<LogInEvent> ((event, emit) async {
      emit(LoginLoadingState());
      try{
        final user = await loginUseCase.call( event.email,event.password);
        user.fold((l) => emit(LoginErrorState("Fail to Login")), (r) => emit(UserLoggedState(r)));  
      } catch (e) {
        emit(LoginErrorState("Fail to Login")); 
     }
      
    });

  }


  
  
}