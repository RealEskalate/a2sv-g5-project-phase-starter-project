import handler from './options';

export { handler as GET, handler as POST };
